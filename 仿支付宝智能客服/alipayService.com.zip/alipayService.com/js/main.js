$(function(){
    //倒计时
    var m=59;
    var s=59;
    setInterval(function(){
        if(s<10){
            $('.time').html(m+':0'+s);
        }else{
            $('.time').html(m+':'+s);
        }
        s--;
        if(s<0){
            s=59;
            m--;
        }
    },1000)

    /* 滚动导航*/
    $(".find_nav_list").css("left",sessionStorage.left+"px");
    $(".find_nav_list li").each(function(){
        if($(this).find("a").text()==sessionStorage.pagecount){
            $(".sideline").css({left:$(this).position().left});
            $(".sideline").css({width:$(this).outerWidth()});
            $(this).addClass(".find_nav_cur").siblings().removeClass(".find_nav_cur");
            navName(sessionStorage.pagecount);
            return false
        }
        else{
            $(".sideline").css({left:0});
            $(".find_nav_list li").eq(0).addClass(".find_nav_cur").siblings().removeClass(".find_nav_cur");
        }
    });
    var nav_w=$(".find_nav_list li").first().width();
    $(".sideline").width(nav_w);
    $(".find_nav_list li").on('click', function(){
        nav_w=$(this).width();
        $(".sideline").stop(true);
        $(".sideline").animate({left:$(this).position().left},300);
        $(".sideline").animate({width:nav_w});
        $(this).addClass(".find_nav_cur").siblings().removeClass(".find_nav_cur");
        var fn_w = ($(".find_nav").width() - nav_w) / 2;
        var fnl_l;
        var fnl_x = parseInt($(this).position().left);
        if (fnl_x <= fn_w) {
            fnl_l = 0;
        } else if (fn_w - fnl_x <= flb_w - fl_w) {
            fnl_l = flb_w - fl_w;
        } else {
            fnl_l = fn_w - fnl_x;
        }
        $(".find_nav_list").animate({
            "left" : fnl_l
        }, 300);
        sessionStorage.left=fnl_l;
        var c_nav=$(this).find("a").text();
    });
    var fl_w=$(".find_nav_list").width();
    var flb_w=$(".find_nav_left").width();
    $(".find_nav_cur").click();
    $(".find_nav_list").on('touchstart', function (e) {
        var touch1 = e.originalEvent.targetTouches[0];
        x1 = touch1.pageX;
        y1 = touch1.pageY;
        ty_left = parseInt($(this).css("left"));
    });
    $(".find_nav_list").on('touchmove', function (e) {
        var touch2 = e.originalEvent.targetTouches[0];
        var x2 = touch2.pageX;
        var y2 = touch2.pageY;
        if(ty_left + x2 - x1>=0){
            $(this).css("left", 0);
        }else if(ty_left + x2 - x1<=flb_w-fl_w){
            $(this).css("left", flb_w-fl_w);
        }else{
            $(this).css("left", ty_left + x2 - x1);
        }
        if(Math.abs(y2-y1)>0){
            e.preventDefault();
        }
    });


    /* 结算*/
   $(".modal-btn").click(function(){
       $('#jieSuan-modal').modal('toggle');
   });
    //选中效果
    $(".sel-table2 li").click(function () {
        var $this = $(this);
        $(this).addClass("active").siblings("li").removeClass("active");
    });
    $(".sel-table3 li").click(function () {
        var $this = $(this);
        $(this).addClass("active").siblings("li").removeClass("active");
    });

   /* 点击发送消息*/
    $(".question-btn").click(function(){
        var info= this.innerText;
        str2  = '<div class="question">';
        str2 += '<div class="heard_img right"><img src="images/dglvyou2.jpg"></div>';
        str2 += '<div class="question_text clear"><p>'+info+'</p><i></i>';
        str2 += '</div></div>';
        $('.speak_box').append(str2);
        for_bottom();
        setTimeout(function () {
            var ans2 = '<div class="answer"><div class="heard_img left"><img src="images/dglvyou.jpg"></div>';
            if (str2.indexOf("封盘汇总") != -1) {
                ans2 += '<div class="answer_text"><p>1</p><i></i>';
            } else if (str2.indexOf("个人结算") != -1) {
                ans2 += '<div class="answer_text"><p>2</p><i></i>';
            }
            else if (str2.indexOf("下单投注") != -1) {
                ans2 += '<div class="answer_text"><p>3</p><i></i>';
            }
            else {
                ans2 += '<div class="answer_text"><p>4</p><i></i>';
            }
            $('.speak_box').append(ans2);
            for_bottom();
        }, 1000);
    });
});

//消息列表
function up_say(){
    //用户消息
    var text = $('.write_box input').val(),
    str  = '<div class="question">';
    str += '<div class="heard_img right"><img src="images/dglvyou2.jpg"></div>';
    str += '<div class="question_text clear"><p>'+text+'</p><i></i>';
    str += '</div></div>';

  /*  $.ajax({
        type: 'post',
        dataType: 'jsonp',
        url: "",
        jsonp: 'callback',
        jsonpClaaback: "success_jsonpCallback",
        success: function (result) {
            if (result.code == 0) {
                alert("消息发送成功！")
                $(".write_box input").val("");
            } else {
                alert("消息发送失败！")
            }
        }
    });*/

    //消息为空
    if(text == ''){
        alert('不能发送空白信息');
        $('.write_box input').focus();
    }else {
        $('.speak_box').append(str);
        $('.write_box input').val('');
        $('.write_box input').focus();
        for_bottom();
        /*默认回复*/
        var moRen = '<table class=" table table-striped">'
            + '                <caption class="text-center">你可能想以下问题(回复文字即可)：</caption>'
            + '                <tbody>'
            + '                <tr>'
            + '                    <td class="question-btn">下单投注</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td class="question-btn">开奖记录</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td class="question-btn">封盘汇总</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td class="question-btn">个人结算</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td class="question-btn">其他问题</td>'
            + '                </tr>'
            + '                </tbody>'
            + '            </table>'
        /*封盘汇总*/
        var huiZon = '<table class="table table-striped">'
            + '                <caption>【封盘汇总】665804期</caption>'
            + '                <thead>'
            + '                <tr>'
            + '                    <th>人数 299</th>'
            + '                    <th>总积分 2982</th>'
            + '                </tr>'
            + '                </thead>'
            + '                <tbody>'
            + '                <tr>'
            + '                    <td>号码</td>'
            + '                    <td>积分</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>1</td>'
            + '                    <td>500</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>2</td>'
            + '                    <td>200</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>3</td>'
            + '                    <td>400</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>1</td>'
            + '                    <td>1000</td>'
            + '                </tr>'
            + '                </tbody>'
            + '            </table>'
        /*封盘汇总*/
        var jieSuan = '<table class="table table-striped">'
            + '                <caption>【个人结算】665804期</caption>'
            + '                <tbody>'
            + '                <tr>'
            + '                    <td>投注号码 5</td>'
            + '                    <td>赔率 1.95</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td colspan="2">投注时间：2018-02-09 13:30</td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td colspan="2">订单编号：4489524899554556</td>'
            + '                </tr>'
            + '                </tbody>'
            + '            </table>'
        /*投注下单*/
        var touZu = '<table class="table table-bordered sel-table1">'
            + '                <caption>【下单投注】665804期</caption>'
            + '                <tbody>'
            + '                <tr>'
            + '                    <td class="active">宾利<i class="fa fa-check"></i></td>'
            + '                    <td>奔驰<i class="fa fa-check"></i></td>'
            + '                    <td>宝马<i class="fa fa-check"></i></td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>奥迪<i class="fa fa-check"></i></td>'
            + '                    <td>路虎<i class="fa fa-check"></i></td>'
            + '                    <td>捷豹<i class="fa fa-check"></i></td>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td>大众<i class="fa fa-check"></i></td>'
            + '                    <td>奇瑞<i class="fa fa-check"></i></td>'
            + '                    <td>哈佛<i class="fa fa-check"></i></td>'
            + '                </tr>'
            + '                </tbody>'
            + '            </table>'
            + '            <table class="table table-bordered sel-table2">'
            + '                <tr>'
            + '                    <th colspan="3">选择投注金额:</th>'
            + '                </tr>'
            + '                <tr>'
            + '                    <td class="active">100<i class="fa fa-check"></i></td>'
            + '                    <td >200<i class="fa fa-check"></i></td>'
            + '                    <td >300<i class="fa fa-check"></i></td>'
            + '                </tr>'
            + '            </table>'
            + '            <table class="table sel-table3">'
            + '                <tr>'
            + '                    <td class="text-left"><strong>投注总额：</strong></td>'
            + '                    <td class="text-right">选中<strong>宝马</strong>    <strong>200 <i class="fa fa-database"></i></strong></td>'
            + '                </tr>'
            + '                <tr>'
            + '                   <td colspan="2">'
            + '                       <a class="btn btn-sm btn-danger ">确认下注</a>'
            + '  </td>'
            + '  </tr>'
            + '  </table>'

        //系统回复
        setTimeout(function () {
            var ans = '<div class="answer"><div class="heard_img left"><img src="images/dglvyou.jpg"></div>';
            if (text.indexOf("封盘汇总") != -1) {
                ans += '<div class="answer_text"><p>' + huiZon + '</p><i></i>';
            } else if (text.indexOf("个人结算") != -1) {
                ans += '<div class="answer_text"><p>' + jieSuan + '</p><i></i>';
            }
            else if (text.indexOf("下单投注") != -1) {
                ans += '<div class="answer_text"><p>' + touZu + '</p><i></i>';
            }
            else {
                ans += '<div class="answer_text"><p>' + moRen + '</p><i></i>';
            }
            $('.speak_box').append(ans);
            for_bottom();
        }, 1000);

        /*var ans = '';
        $.ajax({
            type: 'get',
            dataType: 'jsonp',
            url: "",
            jsonp: 'callback',
            jsonpClaaback: "success_jsonpCallback",
            success: function (result) {
                if (result.data.contentList) {
                    //清空HTML代码
                    ans.html("");
                    getListHTML = "";
                    for (var i = 0; i < result.data.contentList.length; i++) {
                        //列表内容HTML
                        var ans = '<div class="answer"><div class="heard_img left"><img src="images/dglvyou.jpg"></div>';
                    }
                    $(".comment-show").append(getListHTML);
                } else {
                    ans += '<div class="answer_text"><p>消息错误</p><i></i>';
                }
            }
        });*/
    }
}

//会话向下滚动
function for_bottom(){
    var speak_height = $('.speak_box').height();
    $('.speak_box,.speak_window').animate({scrollTop:speak_height},500);
}